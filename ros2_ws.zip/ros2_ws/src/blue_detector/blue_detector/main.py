import rclpy
from testing import BlueAreaDetector
from marker_publish import BlueMarkerPublisher
import cv2

def main():
    # Initialize ROS 2
    rclpy.init()
    
    # Create detector and publisher
    detector = BlueAreaDetector()
    publisher = BlueMarkerPublisher()
    
    try:
        if detector.load_image_file():
            detector.image = cv2.cvtColor(detector.image, cv2.COLOR_BGR2RGB)
            blue_mask, _ = detector.detect_blue_areas()
            marked_image = detector.mark_blue_areas(blue_mask)
            
            cv2.imshow("Blue Areas Detected", marked_image)
            cv2.imshow("Blue Mask", blue_mask)

            print(detector.generate_report())
            
            # Publish detected markers via ROS 2
            publisher.publish_blue_markers(detector.blue_areas)
            
            # Print report
            print(detector.generate_report())
            
            # Display results
            cv2.imshow("Blue Areas Detected", marked_image)
            cv2.waitKey(0)
            
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        publisher.destroy_node()
        rclpy.shutdown()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()