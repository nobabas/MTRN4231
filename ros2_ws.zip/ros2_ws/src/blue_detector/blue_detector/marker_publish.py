from geometry_msgs.msg import Point, PointStamped
from std_msgs.msg import Header
import rclpy
from rclpy.node import Node

class BlueMarkerPublisher(Node):
    def __init__(self):
        super().__init__('blue_marker_publisher')
        
        # Publish as Point messages
        self.marker_publisher = self.create_publisher(
            PointStamped, 
            '/blue_markers', 
            10
        )
    
    def publish_blue_markers(self, blue_areas):
        for i, area in enumerate(blue_areas):
            cx, cy = area['center']
            
            point_msg = PointStamped()
            point_msg.header = Header()
            point_msg.string = "command"
            point_msg.point = float[cx, cy, 0.1, 0,0,0]  # x,y,z,roll,pitch,yaw
            point_msg.bool = True  # Indicate this is a valid point
            
            self.marker_publisher.publish(point_msg)