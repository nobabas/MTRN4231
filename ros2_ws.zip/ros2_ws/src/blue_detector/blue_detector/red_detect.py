import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog, messagebox
import os
from datetime import datetime
import json

class RedAreaDetector:
    def __init__(self):
        self.image = None
        self.red_areas = []
        self.min_red_area = 100  # Minimum area to consider as a red region (pixels)

    def load_image_file(self):
        """Load field image from file"""
        root = tk.Tk()
        root.withdraw()

        # file_path = "/home/mtrn/4231/received_images/current_image.jpg"
        file_path = "C:/Users/61410/Downloads/20250725_152522.jpg"

        
        if file_path:
            self.image = cv2.imread(file_path)
            if self.image is not None:
                print(f"Image loaded: {self.image.shape[1]}x{self.image.shape[0]}")
                return True
            else:
                messagebox.showerror("Error", "Could not load image file")
                return False
        return False
    
    def detect_red_areas(self, sensitivity=30, roi=None):
        if self.image is None:
            return False

        if roi:
            x, y, w, h = roi
            hsv = hsv[y:y+h, x:x+w]

        # Convert to HSV
        hsv = cv2.cvtColor(self.image, cv2.COLOR_BGR2HSV)

        # Define red color ranges
        lower_red1 = np.array([0, 120, 70])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([170, 120, 70])
        upper_red2 = np.array([180, 255, 255])

        # Create masks and combine them
        mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
        mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
        red_mask = cv2.bitwise_or(mask1, mask2)



        #red_mask = cv2.inRange(hsv, lower_red, upper_red)

        # Clean mask
        kernel = np.ones((5, 5), np.uint8)
        red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_CLOSE, kernel)
        red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel)

        contours, _ = cv2.findContours(red_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        self.red_areas = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > self.min_red_area:
                x_c, y_c, w_c, h_c = cv2.boundingRect(contour)

                # Adjust positions if cropped
                if roi:
                    x_c += x
                    y_c += y

                moments = cv2.moments(contour)
                if moments["m00"] != 0:
                    cx = int(moments["m10"] / moments["m00"]) + (x if roi else 0)
                    cy = int(moments["m01"] / moments["m00"]) + (y if roi else 0)
                else:
                    cx, cy = x_c + w_c // 2, y_c + h_c // 2

                self.red_areas.append({
                    'contour': contour,
                    'bbox': (x_c, y_c, w_c, h_c),
                    'center': (cx, cy),
                    'area': area,
                    'pixel_count': cv2.countNonZero(red_mask[y_c - (y if roi else 0):y_c - (y if roi else 0) + h_c, x_c - (x if roi else 0):x_c - (x if roi else 0) + w_c])
                })

        print(f"Detected {len(self.red_areas)} red areas in ROI")
        return red_mask, self.red_areas


    def mark_red_areas(self, red_mask=None, display_original=True):
        """Mark red areas on the image with bounding boxes and labels"""
        if self.image is None:
            return None

        if display_original:
            marked_image = self.image.copy()
        else:
            marked_image = np.zeros_like(self.image)

        for i, area in enumerate(self.red_areas):
            x, y, w, h = area['bbox']
            cv2.rectangle(marked_image, (x, y), (x + w, y + h), (255, 0, 0), 2)
            cv2.drawContours(marked_image, [area['contour']], -1, (0, 255, 255), 2)

            cx, cy = area['center']
            cv2.circle(marked_image, (cx, cy), 5, (0, 0, 255), -1)

            label = f"Red {i+1}: {area['area']:.0f}px"
            cv2.putText(marked_image, label, (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(marked_image, label, (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 1)

        summary_text = f"Total Red Areas: {len(self.red_areas)}"
        cv2.putText(marked_image, summary_text, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
        cv2.putText(marked_image, summary_text, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 1)

        return marked_image

    def generate_report(self):
        """Generate a detailed report of Red areas"""
        if not self.red_areas:
            return "No red areas detected."

        report = f"RED AREAS DETECTION REPORT\n"
        report += f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        report += f"Total RED areas found: {len(self.red_areas)}\n"
        self.xcoord = []
        self.ycoord = []
        for i, area in enumerate(self.red_areas):
            cx, cy = area['center']

            report += f"RED AREA {i+1}:\n"
            report += f"{cx}, {cy}, 0.1, 0, 0, 0\n"
            self.xcoord.append(cx)
            self.ycoord.append(cy)


        return report
    
    def perspective_image(self):
        if self.image is None:
            return False

        hsv = self.image.copy()
        # to do get size of image
        self.generate_report()
        #source
        pts1 = np.float32([
        [self.xcoord[3], self.ycoord[3]],
        [self.xcoord[2], self.ycoord[2]],
        [self.xcoord[1], self.ycoord[1]],
        [self.xcoord[0], self.ycoord[0]],
        ])
        
        # destination
        pts2 = np.float32([[0,0],[300,0],[0,600],[300,600]])
        
        M = cv2.getPerspectiveTransform(pts1,pts2)
        
        #image warp size
        dst = cv2.warpPerspective(hsv,M,(300,600))
        cv2.imshow("Perspective Transform", dst)
        return dst


def main():
    detector = RedAreaDetector()

    if detector.load_image_file():
        #detector.image = cv2.cvtColor(detector.image, cv2.COLOR_BGR2RGB)
        red_mask, _ = detector.detect_red_areas()  # unpack both return values
        marked_image = detector.mark_red_areas(red_mask)
        perspective = detector.perspective_image()
        
        cv2.imshow("Red Areas Detected", marked_image)
        cv2.imshow("Red Mask", red_mask)       
        cv2.imshow("Perspective Transform", perspective)
        
        detector.save_dir = "/home/mtrn/4231/received_images"
        os.makedirs(detector.save_dir, exist_ok=True)
        
        # Default filename with timestamp
        save_path = os.path.join(os.getcwd(), f"/home/mtrn/4231/received_images/perspective_red.jpg")

        cv2.imwrite(save_path, perspective)
        print(f"Perspective image saved as: {save_path}")
        
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()